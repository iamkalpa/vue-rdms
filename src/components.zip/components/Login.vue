<template>
    <div class="login-bg">
        <div id="login_app">
            <!--main block start-->
            <div class="row">
                <div class="container">
                    <div class="loginbg">
                        <div class="login-title">
                            <h1>Login</h1>
                        </div>
                        <div class="login-panel" >
                            <div class="login_frm">
                                <div v-if="err" v-bind:class="[(err) ? 'alert alert-danger alert-sm form-group inpt' : 'alert alert-sm']" v-html="err"></div>
                                <div class="form-group inpt">
                                    <input type="text" placeholder="Mobilenumber" v-model="user_login['mobile_number']" maxlength="10" class="form-control mt-2" autocomplete="off">
                                </div>
                                <div class="sample-captcha">
                                    <div class="form-group inpt">
                                        <input class="form-control mt-2" v-model="inputValue" placeholder="Captcha" type="text">
                                        <span class="highlight"></span>
                                    </div>
                                    <VueClientRecaptcha
                                    :value="inputValue"
                                    @getCode="getCaptchaCode"
                                    @isValid="checkValidCaptcha"
                                    />
                                    
                                </div>
                                <!--<template>
                                <vue-recaptcha sitekey="6LfJA0gUAAAAAA4YDXBubWMll55x5xLpyzu6n60G" :load-recaptcha-script="true"></vue-recaptcha>
                                </template> -->
                                
                                <div>
                                    <input type="button" id="submit_btn" v-on:click="generate_otp"  value="LOGIN"  class="lgn_btn btn mt-3">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script type="module">
    import router from "../router"    
    import axios from "axios"  
    import CryptoJS from 'crypto-js';  
    import { ref } from "vue";
    import '../assets/login.css'
    import VueClientRecaptcha from 'vue-client-recaptcha';
    export default {    
        name: "Login", 
        components: { VueClientRecaptcha },
        setup() {
            /* pass value to captcha  */
            const inputValue = ref(null);
            const getCaptchaCode = (value) => {
            /* you can access captcha code */
            console.log(value);
            };
            const checkValidCaptcha = (value) => {
            /* expected return boolean if your value and captcha code are same return True otherwise return False */
            };
            return {
                inputValue,
                getCaptchaCode,
                checkValidCaptcha,
            };
        },
        data(){
            return {
                user_login:{
                    mobile_number: "",
                    captcha: "",
                    otp:"",
                    err: "",
                },
                err:"",
                key : CryptoJS.enc.Hex.parse("0123456789abcdef0123456789abcdef"),
		        iv :  CryptoJS.enc.Hex.parse("abcdef9876543210abcdef9876543210"),
            }
        },
        methods: {    
            async generate_otp() {
                this.user_login['captcha']=this.inputValue;
                let mobile_exp=/^[6-9]\d{9}$/;
                if(mobile_exp.test(this.user_login['mobile_number']) == false){
                    this.err = 'Enter valid mobile number';
                    //setTimeout(function(v){v.err = '';},2000,this);
                    return false;
                }
                else if(this.user_login['captcha']==''){
                    this.err = 'Enter captcha';
                    return false;
                }
                else{
                    if(!document.getElementById("submit_btn").disabled){
                        let enc_mobile=this.clean_before_submit(this.user_login.mobile_number);
                        var usr_login={
                            "mobile_number":enc_mobile,
                            "captcha":this.user_login.captcha
                        };
                        console.log(usr_login);
                        //return false;
                        try {
                            await axios({
                            url: 'http://localhost:5000/login',
                            method: 'post',
                            data: {
                                //mobile: usr_login['mobile_number']
                                mobile: '9999999999'
                            }
                            }
                            ).then(response => { 
                                alert('success');
                                console.log(response);
                            })
                        }
                        catch(error){
                                console.log(error.response)
                        };
                    }
                }
            },
            clean_before_submit:function(vno){
                var vp = vno;
                var key = this.key;
                var iv=this.iv;
                if( vp != ""){
                        var encrypted = CryptoJS.AES.encrypt(vp, key, {iv:iv});
                        encrypted = encrypted.ciphertext.toString(CryptoJS.enc.Base64);
                }
                return encrypted;  
        	}
            
        }    
    }
</script>